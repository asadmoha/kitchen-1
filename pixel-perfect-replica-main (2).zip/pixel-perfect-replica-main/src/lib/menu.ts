export type Category = "Burgers" | "Chicken" | "Drinks";

export interface Product {
  id: string;
  name: string;
  description: string;
  category: Category;
  price: number; // KES
  image: string;
  available: boolean;
  dietary?: string;
  bestSeller?: boolean;
  photoCredit: string;
}

const u = (id: string) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=900&q=80`;

export const CURRENCY = "KES";
export const formatPrice = (n: number) => `${CURRENCY} ${n.toLocaleString("en-KE")}`;

export const products: Product[] = [
  { id: "classic-beef-burger", name: "Abu Dhabi Classic Beef Burger", description: "Flame-grilled beef patty, aged cheddar, crisp lettuce, tomato, pickles and our signature house sauce on a toasted brioche bun.", category: "Burgers", price: 850, image: u("1568901346375-23c9450c58cd"), available: true, dietary: "Contains gluten, dairy, egg", bestSeller: true, photoCredit: "Unsplash" },
  { id: "grilled-chicken-sandwich", name: "Grilled Chicken Sandwich", description: "Marinated chicken breast, chargrilled and layered with slaw, pickles and creamy garlic sauce.", category: "Chicken", price: 750, image: u("1606755962773-d324e0a13086"), available: true, dietary: "Contains gluten, egg", bestSeller: true, photoCredit: "Unsplash" },
  { id: "crispy-fried-chicken", name: "Crispy Fried Chicken", description: "Golden, crunchy buttermilk-fried chicken pieces with a smoky dipping sauce.", category: "Chicken", price: 900, image: u("1626645738196-c2a7c87a8f58"), available: true, dietary: "Contains gluten, dairy", bestSeller: true, photoCredit: "Unsplash" },
  { id: "fresh-lemonade", name: "Fresh Lemonade", description: "Squeezed to order with fresh lemons, mint and a touch of cane sugar. Served ice-cold.", category: "Drinks", price: 250, image: u("1621263764928-df1444c5e859"), available: true, dietary: "Vegan", photoCredit: "Unsplash" },
  { id: "cola", name: "Cola", description: "A chilled classic cola — the perfect partner for any burger.", category: "Drinks", price: 150, image: u("1554866585-cd94860890b7"), available: true, dietary: "Vegan", photoCredit: "Unsplash" },
  { id: "mango-juice", name: "Mango Juice", description: "Thick, sunny juice blended from ripe mangoes. Nothing added.", category: "Drinks", price: 300, image: u("1623065422902-30a2d299bbe4"), available: true, dietary: "Vegan", photoCredit: "Unsplash" },
];

export const heroImage = u("1571091718767-18b5b1457add").replace("w=900", "w=1600");

export const business = {
  phone: "+254 700 000 000",
  email: "hello@abudhabi.co.ke",
  address: "Moi Avenue, Nairobi, Kenya",
  hours: [
    { days: "Mon – Thu", time: "10:00 – 22:00" },
    { days: "Fri – Sat", time: "10:00 – 00:00" },
    { days: "Sunday", time: "11:00 – 22:00" },
  ],
  onlineOrdering: false,
};
