import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { products, type Product } from "./menu";

type Lines = Record<string, number>;
interface CartCtx {
  lines: { product: Product; qty: number }[];
  count: number;
  subtotal: number;
  add: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
}
const Ctx = createContext<CartCtx | null>(null);
const KEY = "abudhabi-cart";

export function CartProvider({ children }: { children: ReactNode }) {
  const [map, setMap] = useState<Lines>({});
  useEffect(() => {
    try { setMap(JSON.parse(localStorage.getItem(KEY) || "{}")); } catch { /* ignore */ }
  }, []);
  const save = (m: Lines) => { setMap(m); localStorage.setItem(KEY, JSON.stringify(m)); };
  const lines = products.filter((p) => (map[p.id] ?? 0) > 0).map((p) => ({ product: p, qty: map[p.id] ?? 0 }));
  const value: CartCtx = {
    lines,
    count: lines.reduce((a, l) => a + l.qty, 0),
    subtotal: lines.reduce((a, l) => a + l.qty * l.product.price, 0),
    add: (id) => save({ ...map, [id]: (map[id] || 0) + 1 }),
    setQty: (id, qty) => { const m = { ...map }; if (qty <= 0) delete m[id]; else m[id] = qty; save(m); },
    clear: () => save({}),
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
