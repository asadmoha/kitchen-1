import { createFileRoute } from "@tanstack/react-router";
import { HoursBlock } from "@/components/site/HoursBlock";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Visit us — Abu Dhabi" },
      { name: "description", content: "Abu Dhabi opening hours, location and contact details." },
      { property: "og:title", content: "Visit us — Abu Dhabi" },
      { property: "og:description", content: "Opening hours, location and contact details." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <div className="mx-auto max-w-6xl px-5 py-16">
      <h1 className="text-5xl font-semibold md:text-6xl">Come hungry.</h1>
      <p className="mt-3 text-muted-foreground">We'd love to see you. Here's where and when.</p>
      <div className="mt-12"><HoursBlock /></div>
    </div>
  );
}
