import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Leaf, Flame, HeartHandshake, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/site/ProductCard";
import { FoodImage } from "@/components/site/FoodImage";
import { HoursBlock } from "@/components/site/HoursBlock";
import { heroImage, products } from "@/lib/menu";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Abu Dhabi — Big Flavour. Fresh Moments." },
      { name: "description", content: "Flame-grilled burgers, crispy fried chicken and fresh drinks. Explore the Abu Dhabi menu." },
      { property: "og:title", content: "Abu Dhabi — Big Flavour. Fresh Moments." },
      { property: "og:description", content: "Flame-grilled burgers, crispy fried chicken and fresh drinks." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: heroImage },
      { name: "twitter:image", content: heroImage },
    ],
  }),
  component: Home,
});

const testimonials = [
  { name: "Wanjiru K.", text: "The Classic Beef Burger is the best I've had in town. Juicy, generous and fast." },
  { name: "Omar H.", text: "Crispy chicken done right, and the fresh lemonade is the perfect match." },
  { name: "Brian M.", text: "Friendly staff, spotless place and the mango juice tastes like real mangoes." },
];

function Home() {
  const food = products.filter((p) => p.category !== "Drinks");
  const drinks = products.filter((p) => p.category === "Drinks");
  return (
    <>
      <section className="relative overflow-hidden bg-ink text-ink-foreground">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:py-28">
          <div className="animate-rise">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">Nairobi's flame-grilled favourite</p>
            <h1 className="mt-5 text-5xl font-semibold leading-[1.02] md:text-7xl">
              Big Flavour.<br />Fresh Moments.<br /><span className="text-primary">Abu Dhabi.</span>
            </h1>
            <p className="mt-6 max-w-md text-lg text-ink-muted">Hand-pressed burgers, crispy golden chicken and drinks squeezed fresh to order — made with care, served fast.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button asChild variant="hero" size="xl"><Link to="/menu">Explore Our Menu <ArrowRight /></Link></Button>
              <Button asChild variant="heroOutline" size="xl"><Link to="/menu">Order Now</Link></Button>
            </div>
          </div>
          <div className="relative animate-rise [animation-delay:150ms]">
            <div className="aspect-square overflow-hidden rounded-[2.5rem]">
              <FoodImage src={heroImage} alt="Abu Dhabi beef burger" className="h-full w-full" />
            </div>
            <div className="absolute -bottom-5 -left-5 rounded-2xl bg-card px-5 py-4 text-card-foreground shadow-card">
              <p className="text-xs text-muted-foreground">Signature</p>
              <p className="font-display text-lg font-semibold">Classic Beef Burger</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">Best sellers</p>
            <h2 className="mt-3 text-4xl font-semibold md:text-5xl">The ones everyone orders</h2>
          </div>
          <Link to="/menu" className="hidden text-sm font-semibold text-primary md:inline-flex">Full menu →</Link>
        </div>
        <div className="mt-12 grid gap-7 md:grid-cols-3">{food.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      </section>

      <section className="bg-secondary/60">
        <div className="mx-auto max-w-6xl px-5 py-24">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">Fresh drinks</p>
          <h2 className="mt-3 text-4xl font-semibold md:text-5xl">Something cold on the side</h2>
          <div className="mt-12 grid gap-7 md:grid-cols-3">{drinks.map((p) => <ProductCard key={p.id} p={p} />)}</div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl items-center gap-14 px-5 py-24 md:grid-cols-2">
        <div className="grid grid-cols-2 gap-4">
          <FoodImage src={products[2]!.image} alt="Crispy fried chicken" className="aspect-[3/4] w-full rounded-3xl" />
          <FoodImage src={products[3]!.image} alt="Fresh lemonade" className="mt-10 aspect-[3/4] w-full rounded-3xl" />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">About Abu Dhabi</p>
          <h2 className="mt-3 text-4xl font-semibold md:text-5xl">Fast food, taken seriously.</h2>
          <p className="mt-6 text-lg leading-relaxed text-muted-foreground">We started Abu Dhabi with a simple belief: quick food should still be great food. Every patty is pressed by hand, every chicken piece is marinated overnight, and every lemon is squeezed the moment you order.</p>
          <Button asChild variant="pill" size="xl" className="mt-8"><Link to="/about">Our story</Link></Button>
        </div>
      </section>

      <section className="bg-ink text-ink-foreground">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-3">
          {[
            { I: Leaf, t: "Fresh, every day", d: "Vegetables delivered each morning and drinks made to order." },
            { I: Flame, t: "Quality you can taste", d: "Real beef, real chicken, grilled and fried to perfection." },
            { I: HeartHandshake, t: "Service with a smile", d: "Quick, warm and welcoming — every visit." },
          ].map(({ I, t, d }) => (
            <div key={t}>
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary"><I className="h-5 w-5 text-primary-foreground" /></span>
              <h3 className="mt-5 text-2xl font-semibold">{t}</h3>
              <p className="mt-2 text-ink-muted">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <h2 className="text-4xl font-semibold md:text-5xl">What guests say</h2>
          <span className="rounded-full bg-muted px-3 py-1 text-xs text-muted-foreground">Sample reviews — real ones coming soon</span>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure key={t.name} className="rounded-3xl bg-card p-8 shadow-card">
              <Quote className="h-6 w-6 text-primary" />
              <blockquote className="mt-4 leading-relaxed">{t.text}</blockquote>
              <figcaption className="mt-6 text-sm font-semibold">{t.name}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-24"><HoursBlock /></section>
    </>
  );
}
