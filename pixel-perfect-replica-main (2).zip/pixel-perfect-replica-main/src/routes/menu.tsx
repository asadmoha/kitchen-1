import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { ProductCard } from "@/components/site/ProductCard";
import { products } from "@/lib/menu";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Abu Dhabi" },
      { name: "description", content: "Burgers, chicken and fresh drinks with prices in KES." },
      { property: "og:title", content: "Menu — Abu Dhabi" },
      { property: "og:description", content: "Burgers, chicken and fresh drinks with prices in KES." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MenuPage,
});

const cats = ["All", "Burgers", "Chicken", "Drinks"] as const;

function MenuPage() {
  const [cat, setCat] = useState<(typeof cats)[number]>("All");
  const [q, setQ] = useState("");
  const list = products.filter((p) => (cat === "All" || p.category === cat) && (p.name + p.description).toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="mx-auto max-w-6xl px-5 py-16">
      <h1 className="text-5xl font-semibold md:text-6xl">Our menu</h1>
      <p className="mt-3 text-muted-foreground">Made fresh, served fast. All prices in KES.</p>
      <div className="mt-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2">
          {cats.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`rounded-full px-5 py-2 text-sm font-semibold transition-colors ${cat === c ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-secondary/70"}`}>{c}</button>
          ))}
        </div>
        <div className="relative md:w-72">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search the menu" className="rounded-full pl-9" />
        </div>
      </div>
      {list.length ? (
        <div className="mt-10 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">{list.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      ) : (
        <p className="mt-16 text-center text-muted-foreground">No items match “{q}”.</p>
      )}
    </div>
  );
}
