import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { FoodImage } from "@/components/site/FoodImage";
import { products } from "@/lib/menu";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Abu Dhabi" },
      { name: "description", content: "The story behind Abu Dhabi: fresh ingredients, real flavour and fast, friendly service." },
      { property: "og:title", content: "About — Abu Dhabi" },
      { property: "og:description", content: "Fresh ingredients, real flavour and fast, friendly service." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="mx-auto max-w-6xl px-5 py-16">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">Our story</p>
      <h1 className="mt-3 max-w-3xl text-5xl font-semibold leading-tight md:text-6xl">Quick food should still be great food.</h1>
      <FoodImage src={products[0]!.image.replace("w=900", "w=1600")} alt="Abu Dhabi Classic Beef Burger" className="mt-12 aspect-[21/9] w-full rounded-[2rem]" />
      <div className="mt-14 grid gap-10 md:grid-cols-3">
        {[
          ["Hand-made", "Patties pressed by hand and chicken marinated overnight in our own spice blend."],
          ["Made to order", "Nothing sits under a heat lamp. Drinks are squeezed and blended when you order."],
          ["For everyone", "A welcoming place for families, friends and anyone hungry for something good."],
        ].map(([t, d]) => (
          <div key={t}><h3 className="text-2xl font-semibold">{t}</h3><p className="mt-3 text-muted-foreground">{d}</p></div>
        ))}
      </div>
      <Button asChild variant="hero" size="xl" className="mt-14"><Link to="/menu">See the menu</Link></Button>
    </div>
  );
}
