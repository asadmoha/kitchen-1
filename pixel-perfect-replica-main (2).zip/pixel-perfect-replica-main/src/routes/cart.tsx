import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2, ShoppingBag, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FoodImage } from "@/components/site/FoodImage";
import { useCart } from "@/lib/cart";
import { business, formatPrice } from "@/lib/menu";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your cart — Abu Dhabi" },
      { name: "description", content: "Review your Abu Dhabi order." },
      { property: "og:title", content: "Your cart — Abu Dhabi" },
      { property: "og:description", content: "Review your Abu Dhabi order." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { lines, subtotal, setQty } = useCart();
  if (!lines.length)
    return (
      <div className="mx-auto max-w-md px-5 py-28 text-center">
        <ShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
        <h1 className="mt-5 text-4xl font-semibold">Your cart is empty</h1>
        <p className="mt-3 text-muted-foreground">Start with a burger. You won't regret it.</p>
        <Button asChild variant="hero" size="xl" className="mt-8"><Link to="/menu">Explore Our Menu</Link></Button>
      </div>
    );
  return (
    <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-[1fr_380px]">
      <div>
        <h1 className="text-5xl font-semibold">Your cart</h1>
        <ul className="mt-10 divide-y divide-border">
          {lines.map(({ product: p, qty }) => (
            <li key={p.id} className="flex items-center gap-5 py-5">
              <FoodImage src={p.image} alt={p.name} className="h-20 w-20 shrink-0 rounded-2xl" />
              <div className="flex-1">
                <p className="font-semibold">{p.name}</p>
                <p className="text-sm text-muted-foreground">{formatPrice(p.price)}</p>
              </div>
              <div className="flex items-center gap-2 rounded-full bg-secondary p-1">
                <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full" aria-label="Decrease" onClick={() => setQty(p.id, qty - 1)}><Minus /></Button>
                <span className="w-6 text-center font-semibold">{qty}</span>
                <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full" aria-label="Increase" onClick={() => setQty(p.id, qty + 1)}><Plus /></Button>
              </div>
              <span className="w-24 text-right font-semibold">{formatPrice(p.price * qty)}</span>
              <Button size="icon" variant="ghost" aria-label="Remove" onClick={() => setQty(p.id, 0)}><Trash2 /></Button>
            </li>
          ))}
        </ul>
      </div>
      <aside className="h-fit rounded-3xl bg-card p-8 shadow-card">
        <h2 className="text-2xl font-semibold">Order summary</h2>
        <dl className="mt-6 space-y-3 text-sm">
          <div className="flex justify-between"><dt className="text-muted-foreground">Subtotal</dt><dd>{formatPrice(subtotal)}</dd></div>
          <div className="flex justify-between border-t border-border pt-3 text-base font-bold"><dt>Total</dt><dd>{formatPrice(subtotal)}</dd></div>
        </dl>
        {business.onlineOrdering ? (
          <Button variant="hero" size="xl" className="mt-8 w-full">Checkout</Button>
        ) : (
          <div className="mt-8 rounded-2xl bg-secondary p-5 text-sm">
            <p className="font-semibold">Online payment is coming soon</p>
            <p className="mt-1 text-muted-foreground">Call us to place this order for pickup or delivery.</p>
            <Button asChild variant="hero" className="mt-4 w-full"><a href={`tel:${business.phone}`}><Phone /> {business.phone}</a></Button>
          </div>
        )}
      </aside>
    </div>
  );
}
