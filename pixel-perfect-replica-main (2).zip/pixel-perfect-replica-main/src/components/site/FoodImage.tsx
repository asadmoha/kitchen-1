import { useState } from "react";
import { UtensilsCrossed } from "lucide-react";

export function FoodImage({ src, alt, className = "" }: { src: string; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (failed)
    return (
      <div className={`grid place-items-center bg-muted text-muted-foreground ${className}`}>
        <div className="flex flex-col items-center gap-2 text-xs"><UtensilsCrossed className="h-6 w-6" />Photo unavailable</div>
      </div>
    );
  return <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} className={`object-cover ${className}`} />;
}
