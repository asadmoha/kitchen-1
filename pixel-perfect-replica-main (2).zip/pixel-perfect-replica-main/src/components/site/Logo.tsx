export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground font-display text-lg font-bold leading-none">
        A
      </span>
      <span className="font-display text-xl font-semibold tracking-tight">
        Abu<span className="text-primary">·</span>Dhabi
      </span>
    </span>
  );
}
