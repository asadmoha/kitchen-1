import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, Music2 } from "lucide-react";
import { business } from "@/lib/menu";
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm text-ink-muted">Big flavour, fresh moments. Burgers, chicken and fresh drinks made with care, every single day.</p>
          <div className="mt-6 flex gap-3">
            {[Instagram, Facebook, Music2].map((I, i) => <a key={i} href="#" aria-label="Social link" className="grid h-10 w-10 place-items-center rounded-full border border-ink-foreground/20 hover:bg-ink-foreground/10"><I className="h-4 w-4" /></a>)}
          </div>
        </div>
        <div>
          <h4 className="font-display text-lg">Explore</h4>
          <ul className="mt-4 space-y-2 text-sm text-ink-muted">
            <li><Link to="/menu" className="hover:text-ink-foreground">Menu</Link></li>
            <li><Link to="/about" className="hover:text-ink-foreground">About us</Link></li>
            <li><Link to="/contact" className="hover:text-ink-foreground">Visit us</Link></li>
            <li><Link to="/cart" className="hover:text-ink-foreground">Your cart</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-lg">Opening hours</h4>
          <ul className="mt-4 space-y-2 text-sm text-ink-muted">
            {business.hours.map((h) => <li key={h.days} className="flex justify-between gap-4"><span>{h.days}</span><span>{h.time}</span></li>)}
          </ul>
          <p className="mt-4 text-sm text-ink-muted">{business.phone}<br />{business.address}</p>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10 py-6 text-center text-xs text-ink-muted">© {new Date().getFullYear()} Abu Dhabi. Food photography via Unsplash.</div>
    </footer>
  );
}
