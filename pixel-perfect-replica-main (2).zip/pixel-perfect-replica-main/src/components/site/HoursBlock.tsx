import { Clock, MapPin, Phone, Mail } from "lucide-react";
import { business } from "@/lib/menu";

export function HoursBlock() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="rounded-3xl bg-card p-8 shadow-card">
        <Clock className="h-6 w-6 text-primary" />
        <h3 className="mt-4 text-2xl font-semibold">Opening hours</h3>
        <ul className="mt-5 space-y-3">
          {business.hours.map((h) => <li key={h.days} className="flex justify-between border-b border-border pb-3 text-sm last:border-0"><span className="font-medium">{h.days}</span><span className="text-muted-foreground">{h.time}</span></li>)}
        </ul>
      </div>
      <div className="rounded-3xl bg-card p-8 shadow-card">
        <MapPin className="h-6 w-6 text-primary" />
        <h3 className="mt-4 text-2xl font-semibold">Find us</h3>
        <ul className="mt-5 space-y-4 text-sm">
          <li className="flex gap-3"><MapPin className="h-4 w-4 text-muted-foreground" />{business.address}</li>
          <li className="flex gap-3"><Phone className="h-4 w-4 text-muted-foreground" /><a href={`tel:${business.phone}`}>{business.phone}</a></li>
          <li className="flex gap-3"><Mail className="h-4 w-4 text-muted-foreground" /><a href={`mailto:${business.email}`}>{business.email}</a></li>
        </ul>
      </div>
    </div>
  );
}
