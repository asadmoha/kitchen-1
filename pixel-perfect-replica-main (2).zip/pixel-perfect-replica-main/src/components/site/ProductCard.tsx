import { Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { formatPrice, type Product } from "@/lib/menu";
import { FoodImage } from "./FoodImage";

export function ProductCard({ p }: { p: Product }) {
  const { add } = useCart();
  return (
    <article className="group flex flex-col overflow-hidden rounded-3xl bg-card shadow-card transition-transform hover:-translate-y-1">
      <div className="relative aspect-[4/3] overflow-hidden">
        <FoodImage src={p.image} alt={p.name} className="h-full w-full transition-transform duration-700 group-hover:scale-105" />
        <span className="absolute left-4 top-4 rounded-full bg-card/90 px-3 py-1 text-xs font-semibold">{p.category}</span>
        {p.bestSeller && <span className="absolute right-4 top-4 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">Best seller</span>}
      </div>
      <div className="flex flex-1 flex-col gap-3 p-6">
        <div className="flex items-start justify-between gap-4">
          <h3 className="text-xl font-semibold leading-tight">{p.name}</h3>
          <span className="shrink-0 font-bold text-primary">{formatPrice(p.price)}</span>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">{p.description}</p>
        {p.dietary && <p className="text-xs text-muted-foreground/80">{p.dietary}</p>}
        <div className="mt-auto flex items-center justify-between pt-2">
          <span className={`text-xs font-medium ${p.available ? "text-chart-4" : "text-destructive"}`}>● {p.available ? "Available" : "Sold out"}</span>
          <Button variant="pill" size="sm" disabled={!p.available} onClick={() => { add(p.id); toast.success(`${p.name} added to cart`); }}>
            <Plus /> Add to cart
          </Button>
        </div>
      </div>
    </article>
  );
}
